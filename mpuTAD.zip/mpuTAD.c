#include <stdlib.h>
#include "mpuTAD.h"

struct mpu {
    SensiAcelerometro sens_ace;
    SensiGiro sens_giro;

    int ax_bruto, ay_bruto, az_bruto;
    int rx_bruto, ry_bruto, rz_bruto;

    float ax, ay, az; 
    float rx, ry, rz;
};

MPU criarMPU() {
    MPU m = malloc(sizeof(struct mpu));
    if (m != NULL) {
        m->sens_ace = ACE_2G;
        m->sens_giro = GIRO_250DPS;
    }
    return m;
}

void destruirMPU(MPU mpu) {
    if (mpu != NULL)
        free(mpu);
}

void setSensiAcelerometro(SensiAcelerometro sens, MPU mpu) {
    if (mpu != NULL)
        mpu->sens_ace = sens;
}

void setSensiGiroscopio(SensiGiro sens, MPU mpu) {
    if (mpu != NULL)
        mpu->sens_giro = sens;
}

void inserirLeiturasBrutas(int ax, int ay, int az, int rx, int ry, int rz, MPU mpu) {
    if (mpu != NULL) {
        mpu->ax_bruto = ax;
        mpu->ay_bruto = ay;
        mpu->az_bruto = az;

        mpu->rx_bruto = rx;
        mpu->ry_bruto = ry;
        mpu->rz_bruto = rz;

        mpu->ax = (float)ax / mpu->sens_ace;
        mpu->ay = (float)ay / mpu->sens_ace;
        mpu->az = (float)az / mpu->sens_ace;

        mpu->rx = (float)rx / mpu->sens_giro;
        mpu->ry = (float)ry / mpu->sens_giro;
        mpu->rz = (float)rz / mpu->sens_giro;
    }
}

void getAcelerometroG(float *ax, float *ay, float *az, MPU mpu) {
    if (mpu == NULL) return;
    *ax = mpu->ax;
    *ay = mpu->ay;
    *az = mpu->az;
}

void getGiroscopioDPS(float *rx, float *ry, float *rz, MPU mpu) {
    if (mpu == NULL) return;
    *rx = mpu->rx;
    *ry = mpu->ry;
    *rz = mpu->rz;

}

void getBrutoAcelerometro(int *ax, int *ay, int *az, MPU mpu) {
    if (mpu == NULL) return;
    *ax = mpu->ax_bruto;
    *ay = mpu->ay_bruto;
    *az = mpu->az_bruto;
}

void getBrutoGiroscopio(int *rx, int *ry, int *rz, MPU mpu) {
    if (mpu == NULL) return;
    *rx = mpu->rx_bruto;
    *ry = mpu->ry_bruto;
    *rz = mpu->rz_bruto;
}
