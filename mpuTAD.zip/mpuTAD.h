#ifndef MPU_TAD_H
#define MPU_TAD_H

/*
Enums para armazenar as sensibilidades do acelerometro e giroscopio.
*/
typedef enum {
    GIRO_250DPS = 131,
    GIRO_500DPS = 65,
    GIRO_1000DPS = 33,
    GIRO_2000DPS = 16
} SensiGiro;

typedef enum {
    ACE_2G = 16384,
    ACE_4G = 8192,
    ACE_8G = 4096,
    ACE_16G = 2048
} SensiAcelerometro;

typedef struct mpu *MPU;

//Funções para criar/destruir o MPU

MPU criarMPU();
void destruirMPU(MPU mpu);

//Getters e setters para o acelerometro e setSensiGiroscopio

/* Define a sensibilidade do acelerometro do MPU. 
   Params: SensiAcelerometro sens, MPU mpu 
*/
void setSensiAcelerometro(SensiAcelerometro sens, MPU mpu);

/* Define a sensibilidade do giroscopio do MPU. 
   Params: SensiGiroscopio sens, MPU mpu 
*/
void setSensiGiroscopio(SensiGiro sens, MPU mpu);

/*
    Busca as acelerações e rotações registradas pelo MPU e recebe os valores via ponteiro.
*/
void getAcelerometroG(float *ax, float *ay, float *az, MPU mpu);
void getGiroscopioDPS(float *rx, float *ry, float *rz, MPU mpu);

/*
    Busca as acelerações e rotações brutas registradas pelo MPU e recebe os valores via ponteiro.
*/
void getBrutoAcelerometro(int *ax, int *ay, int *az, MPU mpu);
void getBrutoGiroscopio(int *rx, int *ry, int *rz, MPU mpu);

/*
    Insere valores brutos de aceleração e rotação no mpu
*/
void inserirLeiturasBrutas(int ax, int ay, int az, int rx, int ry, int rz, MPU mpu);

#endif 
