#include <stdio.h>
#include "mpuTAD.h"

int main() {
    MPU sensor = criarMPU();
    
    int axb, ayb, azb, rxb, ryb, rzb;
    float ax, ay, az, rx, ry, rz;
    
    setSensiAcelerometro(ACE_2G, sensor);
    setSensiGiroscopio(GIRO_250DPS, sensor); 

    inserirLeiturasBrutas(8100, -8100, 0, 130, -55, 10, sensor);

    getBrutoAcelerometro(&axb, &ayb, &azb, sensor);
    getBrutoGiroscopio(&rxb, &ryb, &rzb, sensor);

    printf("Leituras Brutas:\n");
    printf("Acelerômetro (bruto): \nax = %d, \nay = %d, \naz = %d\n", axb, ayb, azb);
    printf("\nGiroscópio (bruto):   \nrx = %d, \nry = %d, \nrz = %d\n", rxb, ryb, rzb);

    getAcelerometroG(&ax, &ay, &az, sensor);
    getGiroscopioDPS(&rx, &ry, &rz, sensor);

    printf("\nLeituras Convertidas:\n");
    printf("Acelerômetro: \nax = %.2fG, \nay = %.2fG, \naz = %.2fG\n", ax, ay, az);
    printf("\nGiroscópio:   \nrx = %.2f°/s, \nry = %.2f°/s, \nrz = %.2f°/s\n", rx, ry, rz);

    destruirMPU(sensor);

    return 0;
}