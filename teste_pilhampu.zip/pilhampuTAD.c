#include <stdlib.h>
#include "pilhampuTAD.h"

struct pilhaMPU {
    MPU sensores[PILHA_MAX];
    int topo;
};

StPilhaMPU criarPilhaMPU() {
    StPilhaMPU p = malloc(sizeof(struct pilhaMPU));
    if (p == NULL) return NULL;
    p->topo = 0;
    return p;
}

void destruirPilhaMPU(StPilhaMPU p) {
    if (p == NULL) return;
    free(p);
}

bool empilhar(MPU mpu, StPilhaMPU p) {
    if (!p || cheia(p)) return false;
    p->topo++;
    p->sensores[p->topo] = mpu;
    return true;
}

MPU desempilhar(StPilhaMPU p) {
    if (!p || vazia(p)) return NULL;
    MPU mpu = p->sensores[p->topo];
    p->topo--;
    return mpu;
}

int tamanho(StPilhaMPU p) {
    if (!p) return 0;
    return p->topo;
}

bool cheia(StPilhaMPU p) {
    if (!p) return false;
    return p->topo == PILHA_MAX;
}

bool vazia(StPilhaMPU p) {
    if (!p) return true;
    return p->topo == 0;
}
