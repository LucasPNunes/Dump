#ifndef PILHAMPU_TAD_H
#define PILHAMPU_TAD_H

#include "mpuTAD.h"
#include <stdbool.h>

#define PILHA_MAX 100

typedef struct pilhaMPU *StPilhaMPU;

StPilhaMPU criarPilhaMPU();
void destruirPilhaMPU(StPilhaMPU p);

bool empilhar(MPU mpu, StPilhaMPU p);
MPU desempilhar(StPilhaMPU p);
int tamanho(StPilhaMPU p);
bool cheia(StPilhaMPU p);
bool vazia(StPilhaMPU p);

#endif