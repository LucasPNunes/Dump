#include <stdio.h>
#include "pilhampuTAD.h"
#include "mpuTAD.h"

int main() {
    StPilhaMPU pilha = criarPilhaMPU();
    if (!pilha) {
        printf("Erro ao criar a pilha.\n");
        return 1;
    }

    MPU mpu1 = criarMPU();
    MPU mpu2 = criarMPU();

    if (!empilhar(mpu1, pilha))
        printf("Falha ao empilhar mpu1\n");
    if (!empilhar(mpu2, pilha))
        printf("Falha ao empilhar mpu2\n");

    printf("Tamanho da pilha após empilhar 2 MPUs: %d\n", tamanho(pilha));
    while (!vazia(pilha)) {
        MPU m = desempilhar(pilha);
        if (m != NULL) {
            printf("Desempilhado MPU\n");
            destruirMPU(m);
        }
    }

    printf("Tamanho da pilha após desempilhar todos MPUs: %d\n", tamanho(pilha));

    destruirPilhaMPU(pilha);

    return 0;
}
